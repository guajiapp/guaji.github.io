<?php 
$con = mysqli_connect('localhost', 'root', 'root', 'gua');
if (!$con){
    echo"���ݿ�����ʧ��";
}else {
 $query = "select * from users where name = '{$_POST['user_name']}' and pass = '{$_POST['user_pass']}'";
        $result = mysqli_query($con, $query);
        if (mysqli_num_rows($result) == 1){
	echo "1036";
	}else{
	echo "1072";
	    }
    }
?>