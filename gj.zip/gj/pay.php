<?php
$data=$_POST['data'];
if($data){
	echo 200;
	}
?>