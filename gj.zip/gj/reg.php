<?php 
$con = mysqli_connect('localhost', 'root', 'root', 'gua');
if (!$con) {
    die('Could not connect: ' . mysqli_connect_error());
}else {
   
    $query = "insert into users (id,name,pass,date) values(null,'{$_POST['user_name']}','{$_POST['user_pass']}',null)";
   
    $result=mysqli_query($con, $query);
    if(!$result){
    echo mysqli_error($con);
    }else{
    echo "1024";    //�ɹ����ע��ɹ�
	}
     

}
?>
